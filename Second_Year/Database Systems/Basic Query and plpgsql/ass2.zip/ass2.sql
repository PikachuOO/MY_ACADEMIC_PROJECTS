-- COMP3311 13s2 Assignment 2
-- Written by YOUR_NAME, September 2013

-- Q1: ...

create or replace view Q1(unswid, name)
as
... one SQL statement, possibly using other views defined by you ...
;

-- Q2: ...

create or replace view Q2(nstudents, nstaff, nboth)
as
... one SQL statement, possibly using other views defined by you ...
;

-- Q3: ...

create or replace view Q3(name, ncourses)
as
... one SQL statement, possibly using other views defined by you ...
;

-- Q4: ...

create or replace view Q4a(id)
as
... one SQL statement, possibly using other views defined by you ...
;

create or replace view Q4b(id)
as
... one SQL statement, possibly using other views defined by you ...
;

create or replace view Q4c(id)
as
... one SQL statement, possibly using other views defined by you ...
;

-- Q5: ...

create or replace view Q5(name)
as
... one SQL statement, possibly using other views defined by you ...
;

-- Q6: ...

create or replace function Q6(integer) returns text
as
$$
... one SQL statement, possibly using other views defined by you ...
$$ language sql
;

-- Q7: ...

create or replace function Q7(text)
	returns table (course text, year integer, term text, convenor text)
as $$
... one SQL statement, possibly using other views defined by you ...
$$ language sql
;

-- Q8: ...

create or replace function Q8(integer)
	returns setof NewTranscriptRecord
as $$
declare
	... PLpgSQL variable delcarations ...
begin
	... PLpgSQL code ...
end;
$$ language plpgsql
;


-- Q9: ...

create or replace function Q9(integer)
	returns setof AcObjRecord
as $$
declare
	... PLpgSQL variable delcarations ...
begin
	... PLpgSQL code ...
end;
$$ language plpgsql
;

